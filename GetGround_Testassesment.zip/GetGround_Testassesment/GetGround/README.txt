
Welcome to the Selenium Webdriver- CUCUMBER framework
project name -> GetGround

A Behavioral driven automation framework with webdriver and cucumber-java.

Pre-requisites
Stable java version greater than or equal to 11 and maven installed 3.8.1

Framework Installation

Browser driver configurations(GetGround\src\main\java\resources\data.properties)
For running the automated test cases through any browsers [eg: Chrome or firefox], you need suitable drivers relevant to your browser versions installed

Automation Execution
Execute the feature file through command line:
go to project loaction-> mvn test

Reports

cucumber report is generated in index.html (target\cucumber-html-report)

