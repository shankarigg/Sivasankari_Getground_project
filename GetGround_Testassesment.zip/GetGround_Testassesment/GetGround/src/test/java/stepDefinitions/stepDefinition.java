package stepDefinitions;


import PageObjects.nhsHelpForm;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.JavascriptExecutor;
import resources.setup;


public class stepDefinition extends setup {
    @Given("^Initialize the browser with chrome/IE$")
    public void initialize_the_browser_with_chrome_IE() throws Exception {
        driver = initializeDriver();
        driver.manage().window().maximize();

    }

    @Given("^Navigate to \"([^\"]*)\" Site$")
    public void navigate_to_Site(String arg1) throws Exception {
        driver.get(arg1);

    }

    @Given("^Click on start link in home page$")
    public void click_on_start_link_in_home_page() throws Exception {
        nhsHelpForm nhs= new nhsHelpForm(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        nhs.getContinueButton().click();

    }

    @When("^User enters all the details and continue to last page$")
    public void user_enters_all_the_details_and_continue_to_last_page() throws Exception {
        nhsHelpForm nhs= new nhsHelpForm(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        nhs.getAcceptCookie().click();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        nhs.getCountryName().click();
        nhs.getContinueButton().click();
        nhs.getdobDay().sendKeys("11");
        nhs.getdobMonth().sendKeys("07");
        nhs.getdobYear().sendKeys("1993");
        nhs.getContinueButton().click();
        nhs.getYesLabel().click();
        nhs.getContinueButton().click();
        nhs.getYesLabel().click();
        nhs.getContinueButton().click();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        nhs.getPartnerClaim().click();
        nhs.getContinueButton().click();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        nhs.getYesLabel().click();
        nhs.getContinueButton().click();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        nhs.getYesLabel().click();
        nhs.getContinueButton().click();
    }

    @Then("^Verify that user can get help or not$")
    public void verify_that_user_can_get_help_or_not() throws Exception {
        nhsHelpForm nhs = new nhsHelpForm(driver);
        String result = nhs.getFinalMsg().getText();

        if(result.contains("You get help with NHS costs")){
          System.out.println("Yes! You can get Help");
        }
        else {
            System.out.println("No! You don't get Help");
        }
    }

    @Then("^close browsers$")
    public void close_browsers() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        driver.quit();
    }

}
