package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class nhsHelpForm {

    public WebDriver driver;

    By continueButton = By.cssSelector("#next-button");
    By countryName = By.cssSelector("#label-wales");
    By dobDay = By.cssSelector("#dob-day");
    By dobMonth = By.cssSelector("#dob-month");
    By dobYear = By.cssSelector("#dob-year");
    By yeslabel = By.cssSelector("#label-yes");
    By partnerClaim = By.cssSelector("label.block-label.selection-button-radio.radio-group");
    By finalmsg = By.cssSelector("h2.heading-large");
    By acceptCookie = By.cssSelector("#nhsuk-cookie-banner__link_accept_analytics");





    public nhsHelpForm(WebDriver driver){
        this.driver = driver;
    }

    public WebElement getContinueButton(){ return driver.findElement(continueButton);}
    public WebElement getCountryName(){ return driver.findElement(countryName);}
    public WebElement getdobDay(){ return driver.findElement(dobDay);}
    public WebElement getdobMonth(){ return driver.findElement(dobMonth);}
    public WebElement getdobYear(){ return driver.findElement(dobYear);}
    public WebElement getYesLabel(){ return  driver.findElement(yeslabel);}
    public WebElement getPartnerClaim(){ return  driver.findElement(partnerClaim);}
    public WebElement getFinalMsg(){ return  driver.findElement(finalmsg);}
    public WebElement getAcceptCookie(){ return  driver.findElement(acceptCookie);}





}
